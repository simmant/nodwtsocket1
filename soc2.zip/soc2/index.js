var app = require('express')();
var http = require('http').createServer(app);
var io = require('socket.io')(http);
var procData = require('./processmodule');

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});


io.on('connection', (socket) => {
  socket.on('chat message', (msg) => {
    var data = 	procData.processData(msg);
    var jsonData = JSON.stringify(data); 	
    var parData = JSON.parse(jsonData);
    console.log('message: ' + jsonData);	    
    console.log('id: ' + socket.id);
    io.to(socket.id).emit('chat message', parData._eventsCount);
  });
});


http.listen(3000, () => {
  console.log('listening on *:3000');
});
