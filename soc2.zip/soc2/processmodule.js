var data2 = '';
exports.processData = function (value) {



return require('https').get('https://www.googleapis.com/customsearch/v1?key=AIzaSyBpG3ZB3slr8QkrXV39e9dd7Gn_xrYft6A&cx=017576662512468239146:omuauf_lfve&q='+value, (res) => {
    res.setEncoding('utf8');
    res.on('data', function (body) {
        
    });
});




};



