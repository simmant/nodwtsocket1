exports.replyMessage = function (value) {

if(value == 'hi')  
return 'Hi How are you mate';

if(value=='hello')
return 'Hello How are you mate';

}; 
