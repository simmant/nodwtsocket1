const https = require('https');
var data2 = '';
exports.replyMessage = function (value) {



https.get('https://www.googleapis.com/customsearch/v1?key=AIzaSyBpG3ZB3slr8QkrXV39e9dd7Gn_xrYft6A&cx=017576662512468239146:omuauf_lfve&q='+value, (resp) => {
  let data = '';

  // A chunk of data has been recieved.
  resp.on('data', (chunk) => {
    data += chunk;
  });

  // The whole response has been received. Print out the result.
  resp.on('end', () => {
    //console.log(JSON.parse(data).explanation);
    //  console.log(data);    
    var allData = JSON.parse(data);
    data2 = allData.items[0].snippet;
  });

}).on("error", (err) => {
  console.log("Error: " + err.message);
});


return data2;

}; 
